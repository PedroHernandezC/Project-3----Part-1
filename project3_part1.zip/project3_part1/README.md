# Project 2 -- Recursive Lists
## Student Information: 
**Name**: Pedro Hernandez Carranza 

**Student ID**: 008806974

**Repository Link**: https://github.com/PedroHernandezC/Project-3----Part-1

## Reflection
This was more very different from what we have been lately and when first starting I felt. My fisrt hurdle was getting the program to compile. I had to update my compiler and consult with chatGPT on how to write the given commands on my machine. Then I had to properly understand the project statement and how the main cpp file was written so that I could write the functions. The most difficult part of this was getting the function to properly read and output to a file.


- Collaboration & Sources:
 - I used AI for general questions concerning the use of the file system and compiling with the correct command prompts. It also suggested the use of a flag for checking for apostrophes instead of making direct comparisons. Dont know if this is better but it felt more readable.
 - The clarifying question asked in class helped a lot and so did the break down of part 1 on canvas.
  

- Implementation Details:
 - The constructor takes the passed path and saves it to the member variable.
 - Tokenize generally tries to open file and if it does then calls readWord. The word returned by readword is then added to the passed vector and or outputfile.
 - readWord takes a file as its parameter and then reads the first word char by char and saving alpha values. Once the end of a word is found the saved chars are returned as a string

- Testing & Status:
  - I used the provided text and the main file for testing. I didnt take a systematic approach but I tried to test for the cases I would think of by changing the main and the provided text file.