//
// Created by Ali Kooshesh on 9/27/25.
//

#include "Scanner.hpp"

#include <utility>
#include <iostream>
#include <fstream>

#include "utils.hpp"

// Pre: parameter is holds directory to input text file
// Post: past path will have been saved to class member inputPath_
Scanner::Scanner(std::filesystem::path inputPath) {
    std::cout << "scanning file " << inputPath << "\n";
    inputPath_= inputPath;
}

// Pre: passed parameter is a vector of strings
// Post: returns UNABLE_TO_OPEN_FILE is unable to open file otherwise past vector will hold all captured words and NO_ERROR will have been returned
error_type Scanner::tokenize(std::vector<std::string>& words) {
    std::cout << "calling Scanner tokenize()" << std::endl;

    std::ifstream inFile(inputPath_);

    if (!inFile.is_open()) {
        std::cout << "not opened";
        return UNABLE_TO_OPEN_FILE;
    }
    std::cout << inputPath_ << " was opened" << std::endl;

    std::string word;

    do {
        word = readWord(inFile);
        words.push_back(word);
    } while (!word.empty());

    inFile.close();

    std::cout << "words been added to vector" << std::endl;


    return NO_ERROR;
}

// Pre: passed parameter is a vector of strings and is able to write to create an output file
// Post: returns UNABLE_TO_OPEN_FILE is unable to open file otherwise past vector will hold all 
//       captured words, filename.tokens will also hold single line entries of the words, and NO_ERROR will have been returned
error_type Scanner::tokenize(std::vector<std::string>& words, const std::filesystem::path& outputFile) {
    auto result = Scanner::tokenize(words);

    if (result != NO_ERROR) {
        return result;
    }

    std::ofstream outFile(outputFile);

    if (!outFile.is_open()) {
        return UNABLE_TO_OPEN_FILE;
    }

    for (const auto& word : words) {
        outFile << word << '\n';
    }

    outFile.close();

    std::cout << "words have been added to file .token" << std::endl;

    return NO_ERROR;
}

// Pre: parameter holds ascii values
// Post: will return complete word excluding any special symbols and trailing apostrophes
std::string Scanner::readWord(std::istream& in) {
    // std::cout << "calling Scanner readWord() \n";
    std::string token = "";
    char ch;
    bool isWord = false;        // true when in a word
    bool apostropheOn = false;  // true when in a word and one has not been found

    while (in.get(ch)) {
        ch = std::tolower(static_cast<unsigned char>(ch));
        
        if (std::isalpha(ch)) {
            token = token + ch;
            isWord = true;
            apostropheOn = true;
        } else if (ch == '\'' && isWord && apostropheOn) {
            token = token + ch;
            apostropheOn = false;
        } else if (isWord) {
            return token;
        }
    }

    return token;
}